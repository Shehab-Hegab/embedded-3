#include <stdbool.h>

#define GPIOB_BASE_ADDR 0x40020400

#define GPIOB_MODER      (*(unsigned long *)(GPIOB_BASE_ADDR + 0x00))
#define GPIOB_OTYPER     (*(unsigned long *)(GPIOB_BASE_ADDR + 0x04))
#define GPIOB_ODR        (*(unsigned long *)(GPIOB_BASE_ADDR + 0x14))

#define RCC_AHB1ENR      (*(unsigned long *)(0x40023800 + 0x30))

#define GPIOB_IDR        (*(unsigned long *)(GPIOB_BASE_ADDR + 0x10))
#define GPIOB_PUPDR      (*(unsigned long *)(GPIOB_BASE_ADDR + 0x0C))

#define RED_PIN   (1 << 5)
#define GREEN_PIN (1 << 6)
#define BLUE_PIN  (1 << 7)
#define BUTTON_PIN (1 << 3)

#define DELAY_TIME 1000000

int main() {
    // Enable clock for Port B
    RCC_AHB1ENR |= (1 << 1);

    // Set LED pins to output mode
    GPIOB_MODER &= ~((0x03 << (5 * 2)) | (0x03 << (6 * 2)) | (0x03 << (7 * 2)));
    GPIOB_MODER |= (0x01 << (5 * 2)) | (0x01 << (6 * 2)) | (0x01 << (7 * 2));

    // Set button pin to input mode with pull-up resistor
    GPIOB_MODER &= ~(0x03 << (3 * 2));
    GPIOB_PUPDR &= ~(0x03 << (3 * 2));
    GPIOB_PUPDR |= (0x01 << (3 * 2));

    // Initialize variables for debouncing and color cycling
    unsigned char lastButtonState =1;
    unsigned char currentButtonState;
    int currentColor = 0;

    while (1) {
        // Read the current state of the button
        currentButtonState = (GPIOB_IDR & BUTTON_PIN) ? 1 : 0;

        // Check for a falling edge (button press)
        if (lastButtonState && !currentButtonState) {
            // Button press detected, change LED color
            GPIOB_ODR &= ~(RED_PIN | GREEN_PIN | BLUE_PIN); // Turn off all LEDs

            // Move to the next color
            currentColor = (currentColor + 1) % 7;

            // Add a delay for button debouncing
            delay(DELAY_TIME);
        }


        // Switch to the next color
        switch (currentColor) {
            case 0:
                GPIOB_ODR |= RED_PIN; // Red
                break;
            case 1:
                GPIOB_ODR |= GREEN_PIN; // Green
                break;
            case 2:
                GPIOB_ODR |= BLUE_PIN; // Blue
                break;
            case 3:
                GPIOB_ODR |= (RED_PIN | GREEN_PIN); // Yellow (Red + Green)
                break;
            case 4:
                GPIOB_ODR |= (RED_PIN | BLUE_PIN); // Magenta (Red + Blue)
                break;
            case 5:
                GPIOB_ODR |= (GREEN_PIN | BLUE_PIN); // Cyan (Green + Blue)
                break;
            case 6:
                GPIOB_ODR |= (RED_PIN | GREEN_PIN | BLUE_PIN); // White (Red + Green + Blue)
                break;
            default:
                GPIOB_ODR &= ~(RED_PIN | GREEN_PIN | BLUE_PIN); // Turn off all LEDs
                break;
        }


        // Store the current button state for the next iteration
        lastButtonState = currentButtonState;
    }

    return 0;
}

// Function for creating delay
void delay(int iterations) {
    for (volatile unsigned long  i = 0; i < iterations; i++) {
        // Delay loop
    }
}
