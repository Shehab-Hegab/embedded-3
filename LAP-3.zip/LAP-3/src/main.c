#define GPIOA_BASE_ADDR 0x40020000  // Base address of Port A registers

#define GPIOA_MODER      (*(unsigned long *)(GPIOA_BASE_ADDR + 0x00)) // MODER register
#define GPIOA_OTYPER     (*(unsigned long *)(GPIOA_BASE_ADDR + 0x04)) // OTYPER register
#define GPIOA_ODR        (*(unsigned long *)(GPIOA_BASE_ADDR + 0x14)) // ODR register

#define RCC_AHB1ENR      (*(unsigned long *)(0x40023800 + 0x30)) // RCC AHB1 Peripheral Clock Enable Register

int main() {

  RCC_AHB1ENR |= (1 << 0);   // Enable clock for Port A

  unsigned char mode_pin_gpio_a = 1;  // Set pin mode for output

  // Clear PA0 bits (ensure correct register and bit offset for PORTA)
  GPIOA_MODER &= ~(0x03 << (0 * 2));

  // Set PA0 for output mode
  GPIOA_MODER |= (mode_pin_gpio_a << (0 * 2));

  GPIOA_OTYPER &= ~(1 << 0);  // Set PA0 to push-pull mode (default)

  while (1) {
    // LED On for 3 seconds
    GPIOA_ODR |= (1 << 0);   // Set PA0 high (turn on LED)
    for (volatile unsigned long i = 0; i < 1500000; i++);  // Delay for 3 seconds (adjust as needed)

    // LED Off for 2 seconds
    GPIOA_ODR &= ~(1 << 0);   // Set PA0 low (turn off LED)
    for (volatile unsigned long i = 0; i < 1000000; i++);  // Delay for 2 seconds (adjust as needed)
  }

  return 0;
}
